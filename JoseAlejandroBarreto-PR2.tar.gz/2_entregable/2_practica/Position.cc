#include "Position.h"

Position::Position(int pos_x, int pos_y) {
  pos_x_ = pos_x;
  pos_y_ = pos_y;
}
Position::Position() {
  pos_x_ = 0;
  pos_y_ = 0;
}