#include "Position.h"

Position::Position(int posicion) {
  posicion_ = posicion;
}
Position::Position() {
  posicion_ = 0;
}